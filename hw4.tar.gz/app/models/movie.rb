class Movie < ActiveRecord::Base
  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end
  
  def self.find_similar_movies(id)
    movie = Movie.find id
    
    unless movie.nil? || movie.director.nil?
      Movie.where director: movie.director
    end 
  end
end
